package com.capg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PageRepository {

	@FindBy(xpath="//*[@id=\\'treemenu\\']/li/ul/li[1]/a")
	@CacheLookup
	WebElement inputForm;
	@FindBy(xpath="//*[@id=\\'treemenu\\']/li/ul/li[1]/ul/li[1]/a")
	@CacheLookup
	WebElement simpleFormDemo;
	@FindBy(xpath="//*[@id=\\'user-message\\']")
	@CacheLookup
	WebElement inputField;
	@FindBy(xpath="//*[@id=\\'get-input\\']/button")
	@CacheLookup
	WebElement submitButton;
	public PageRepository(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	public WebElement getInputForm() {
		return inputForm;
	}

	public void setInputForm(WebElement inputForm) {
		this.inputForm = inputForm;
	}

	public WebElement getSimpleFormDemo() {
		return simpleFormDemo;
	}

	public void setSimpleFormDemo(WebElement simpleFormDemo) {
		this.simpleFormDemo = simpleFormDemo;
	}

	public WebElement getInputField() {
		return inputField;
	}

	public void setInputField(WebElement inputField) {
		this.inputField = inputField;
	}

	public WebElement getSubmitButton() {
		return submitButton;
	}

	public void setSubmitButton(WebElement submitButton) {
		this.submitButton = submitButton;
	}

	
	
	
}


