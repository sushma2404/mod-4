package com.capg.stepdefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.capg.PageRepository;
import com.capg.WebUtil;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {
	WebDriver driver;
	 PageRepository repo;
	@Given("^Open the browser and enter the url$")
	public void open_the_browser_and_enter_the_url() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver=WebUtil.getWebDriver();
		String url="https://www.seleniumeasy.com/test/";
		driver.get(url);
	   
	}

	@When("^Enter the details$")
	public void enter_the_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	 /* WebElement ele1=driver.findElement(By.xpath("//*[@id=\'treemenu\']/li/ul/li[1]/a"));
	  ele1.click();
	  WebElement ele2=driver.findElement(By.xpath("//*[@id=\'treemenu\']/li/ul/li[1]/ul/li[1]/a"));
	  ele2.click();
	  WebElement ele3=driver.findElement(By.xpath("//*[@id=\'user-message\']"));
	  ele3.sendKeys("sushma");
	  WebElement ele4=driver.findElement(By.xpath("//*[@id=\'get-input\']/button"));
	  ele4.click();*/
		WebElement ele1= repo.getInputField(); ele1.click();
		 WebElement ele2=repo.getSimpleFormDemo(); ele2.click();
		 WebElement ele3=repo.getInputField(); ele3.sendKeys("sushma");
		 WebElement ele4=repo.getSubmitButton();ele4.click();
		
		
		
		
	}

	@Then("^Perform operations successfully$")
	public void perform_operations_successfully() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	 
	}



}
