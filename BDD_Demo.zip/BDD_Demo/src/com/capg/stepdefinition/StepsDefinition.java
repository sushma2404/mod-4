package com.capg.stepdefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.capg.WebUtil;
import com.capg.pom.PageObjectRepository;
import com.capg.pom.WebPom;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepsDefinition {
	WebDriver driver;
	PageObjectRepository pageFactory;
	@Given("^Open browser and enter Icompass url$")
	public void open_browser_and_enter_Icompass_url() throws Throwable {
		/*String path = "C:\\Bdd\\drivers\\chromedriver.exe";

		System.setProperty("webdriver.chrome.driver", path);

		 driver = new ChromeDriver();
*/
//		driver=WebPom.getWebDriver();
		driver=WebUtil.getWebDriver();
		String url = "https://icompassweb.fs.capgemini.com";
		driver.get(url);
		pageFactory=new PageObjectRepository(driver);
		
		
	}
	@When("^User enters valid username \"([^\"]*)\" and password \"([^\"]*)\"$")
	public void user_enters_valid_username_and_password(String username, String password) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		
		/*WebElement userTextField =driver.findElement(By.id("userName"));
		WebElement passwordTextField = driver.findElement(By.id("password"));
		userTextField.sendKeys(username);
		System.out.println(userTextField);
		System.out.println(passwordTextField);
		passwordTextField.sendKeys(password);
		WebElement userTextField =WebPom.getUserField();
		WebElement passwordTextField =WebPom.getPasswordField();
		userTextField.sendKeys(username);
		passwordTextField.sendKeys(password);*/
		WebElement userTextField =pageFactory.getUserField();
		userTextField.sendKeys(username);
		WebElement passwordTextField =pageFactory.getPaswwordField();
		passwordTextField.sendKeys(password);
	
		
	}

	@Then("^Display home page successfully$")
	public void display_home_page_successfully() throws Throwable {
		
		/*WebElement loginButton = driver.findElement(By.id("loginButton"));
		loginButton.click();*/
		WebElement loginButton=pageFactory.getLoginButton();//WebPom.getLoginButton();
		loginButton.click();

	}

}
