package com.capg;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "features/login.feature")
public class Login {
	public static void main(String[] args) {
		
		
		
		
		
		
	}

}
