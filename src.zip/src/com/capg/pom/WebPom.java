package com.capg.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.capg.WebUtil;

public class WebPom {

	static WebDriver driver ;
	public static WebDriver getWebDriver()
	{
		driver=  WebUtil.getWebDriver();
		return driver;
	}

	public static WebElement getUserField() {
		return driver.findElement(By.name("userName"));

	}

	public static WebElement getPasswordField() {
		return driver.findElement(By.name("userPwd"));

	}

	public static  WebElement getLoginButton() {
		return driver.findElement(By.className("btn"));

	}
	
}
