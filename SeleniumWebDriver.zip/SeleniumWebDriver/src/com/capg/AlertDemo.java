package com.capg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AlertDemo {
	public static void main(String args[]) throws InterruptedException {
		WebDriver driver = WebUtil.getWebDriver();
		driver.get("C:\\Software\\sts-bundle\\sts-3.9.2.RELEASE\\BDD_Demos\\SeleniumWebDriver\\html\\AlertExample.html");
		WebElement element=driver.findElement(By.name("btnAlert"));
	//	element.click();
		try
		{
			Thread.sleep(5000);
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
		/*try {
		WebDriverWait wait = new WebDriverWait(driver, 5);
		wait.until(ExpectedConditions.alertIsPresent());
		String alertText=	driver.switchTo().alert().getText();
		  System.out.println(alertText);
		//driver.switchTo().alert().accept();
		
		//driver.switchTo().alert().dismiss();
	
	
	}
		catch(Exception e)
		{
			System.out.println(e);
		}*/
	}
}
