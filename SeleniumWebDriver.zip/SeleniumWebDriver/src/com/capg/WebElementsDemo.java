package com.capg;


import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class WebElementsDemo {
	public static void main(String args[]) throws InterruptedException {
		WebDriver driver = WebUtil.getWebDriver();
		String url = "https://www.toolsqa.com/automation-practice-form";
		driver.navigate().to(url);
		/*WebElement element = driver.findElement(By.partialLinkText("SELENIUM"));
		element.click();
		driver.navigate().back();
		WebElement element1 = driver.findElement(By.linkText("ABOUT"));
		element1.click();*/
		/*WebElement drop = driver.findElement(By.id("continents"));
		Select se1=new Select(drop);
		se1.selectByIndex(1);
		WebElement drop = driver.findElement(By.xpath("//*[@id='continents']"));
		Select se1=new Select(drop);
		se1.selectByIndex(1);*/
		WebElement drop = driver.findElement(By.xpath("//select[@name='continents']"));
		Select se1=new Select(drop);
		se1.selectByVisibleText("Africa");
		/*WebElement drop = driver.findElement(By.id("continentsmultiple"));
		Select se1=new Select(drop);
		se1.selectByIndex(0);
		se1.selectByIndex(2);
		System.out.println(se1.isMultiple());*/
	    /* WebElement gender = driver.findElement(By.id("sex-0"));
		 gender.click();*/
	   /*  driver.findElement(By.xpath("//select")).sendKeys(Keys.PAGE_DOWN);
		//WebElement box = driver.findElement(By.id("profession-0"));
		 WebElement box1 = driver.findElement(By.id("tool-0"));
		 WebElement box = driver.findElement(By.id("tool-1"));
	     box.click();
	     box1.click();*/
		
	}

}
