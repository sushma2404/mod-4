package com.capg;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

public class JSExceutorDemo {

	public static void main(String[] args) {
		
		WebDriver driver=WebUtil.getWebDriver();
		//driver.get("C:\\Software\\sts-bundle\\sts-3.9.2.RELEASE\\BDD_Demos\\SeleniumWebDriver\\html\\demo.html");
		driver.get("https://www.javatpoint.com/example-to-connect-to-the-oracle-database");
		JavascriptExecutor js=(JavascriptExecutor) driver;
		//js.executeScript("alert('hello')");
		//js.executeScript("display()");
	//	String str = js.executeScript("return document.getElementById('h1').innerHTML").toString();
		//System.out.println(str);
		js.executeScript("window.scrollBy(0,30)");
	}

}
